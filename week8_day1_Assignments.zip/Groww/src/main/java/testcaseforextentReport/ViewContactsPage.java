package testcaseforextentReport;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class ViewContactsPage extends BaseForExtentReports {
//	public ViewLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public ViewContactsPage verifyFirstName1() {
		String text = getDriver().findElement(By.id("viewContact_firstName_sp")).getText();
	    System.out.println("First name in Create Contact = "+text);
		System.out.println("TC1 Successfull");
		return this;
	}

}
