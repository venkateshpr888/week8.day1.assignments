package testcaseforextentReport;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class MyContactsPage extends BaseForExtentReports {
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public CreateContactsPage clickcontact1() {
		getDriver().findElement(By.linkText(prop1.getProperty("contactTab"))).click();	
		return new CreateContactsPage();
	}

}
