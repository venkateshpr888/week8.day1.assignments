package testcaseforextentReport;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class MyHomePage extends BaseForExtentReports {
//	public MyHomePage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public MyContactsPage ClickContactsTab1() {
		getDriver().findElement(By.linkText("Contacts")).click();
		return new MyContactsPage();
	}
	
}
