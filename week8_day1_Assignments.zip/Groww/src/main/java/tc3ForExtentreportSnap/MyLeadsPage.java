package tc3ForExtentreportSnap;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class MyLeadsPage extends BaseForExtentReports {
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public ViewLeadsPage clickFindLead3() {
		getDriver().findElement(By.xpath("//a[@href='/crmsfa/control/findLeads']")).click();	
		return new ViewLeadsPage();
	}

}
