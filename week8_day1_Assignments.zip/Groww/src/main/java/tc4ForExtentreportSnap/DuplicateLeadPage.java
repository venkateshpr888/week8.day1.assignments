package tc4ForExtentreportSnap;

import org.openqa.selenium.By;

import week8.day1.Assignments.BaseForExtentReports;



public class DuplicateLeadPage extends BaseForExtentReports {
	public ViewLeadPage clickCreateLead4() throws InterruptedException {
		getDriver().findElement(By.xpath("//input[@name='submitButton']")).click();
		Thread.sleep(3000);
		return new ViewLeadPage();
}
}
