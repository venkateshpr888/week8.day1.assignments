package tc4ForExtentreportSnap;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class ViewLeadPage extends BaseForExtentReports{
//	public CreateLeadPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	

	
public DuplicateLeadPage clickDuplicateTab4() throws IOException {
	try {
	getDriver().findElement(By.xpath("//a[text()='R�pliquer le prospect']")).click();
	reportStep("IN TC4 Clicked DuplicateTab Successfully","Pass");
	}catch(Exception e) {reportStep("IN TC4 Clicked DuplicateTab Successfully","Fail");}
	return new DuplicateLeadPage();
}
public ViewLeadPage verifyLeadforDuplicate4() {
	String text3 = getDriver().findElement(By.xpath("//span[@id=\"viewLead_firstName_sp\"]")).getText();
	System.out.println(text3);
	if (text3.equals(text)) {
		System.out.println("the duplicated lead name is same as captured name");
		
	} else {
		System.out.println("the duplicated lead name is NOT same as captured name");
	}
	System.out.println("TC4 Successfull");
	return this;
}
}