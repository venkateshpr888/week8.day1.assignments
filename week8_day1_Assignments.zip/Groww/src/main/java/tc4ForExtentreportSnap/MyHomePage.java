package tc4ForExtentreportSnap;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class MyHomePage extends BaseForExtentReports{
//	public MyHomePage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public MyLeadsPage clickLeadsTab4() {
		
		getDriver().findElement(By.linkText(prop1.getProperty("linkcreatelead"))).click();
		return new MyLeadsPage();
	}
	
}
