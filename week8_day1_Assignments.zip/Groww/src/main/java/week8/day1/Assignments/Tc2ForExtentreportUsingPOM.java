package week8.day1.Assignments;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import tc2ForExtentreportSnap.LoginPage2;






public class Tc2ForExtentreportUsingPOM extends BaseForExtentReports{

	@Test
	public void CreateLead() throws InterruptedException, IOException {
		new LoginPage2()
		.typeUserName2("DemoCsr2")
		.typePassword2("crmsfa")
		.clickLogin2()
		.clickCRMSFA2()
		.clickLeadsTab2()
		.clickcreateLead2()
		.typeCompanyName2("TestLeaf")
		.typeFirstName2("venkatesh")
		.typeLastName2("Ravi")
		.typeEmailAddress2("venkatesh@gmail.com")
		.clickSubmit2()
		.verifyFirstName2();
	
	}@BeforeTest
	public void setData()
	{
		
		testName="TC2 PASSWORD";
		TestDescription="Verify";
		Author="venkatesh";
		category="regression";
	}}
