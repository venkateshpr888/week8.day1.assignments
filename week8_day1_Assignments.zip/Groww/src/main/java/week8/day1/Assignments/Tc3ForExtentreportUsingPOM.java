package week8.day1.Assignments;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import tc3ForExtentreportSnap.LoginPage3;



public class Tc3ForExtentreportUsingPOM extends BaseForExtentReports{

	@Test
	public void CreateLead() throws IOException {
		
		new LoginPage3()
		.typeUserName3("DemoCsr2")
		.typePassword3("crmsfa")
		.clickLogin3()
		.clickCRMSFA3()
		.clickLeadsTab3()
		.clickFindLead3()
		.clickFirstLead3()
		.clickEditTab3()
		.changeCompanyName3("LEAF TEST")
		.ClickSubmit3()
		.verifyEditedOrNot3();
		
		
	}
	@BeforeTest
	public void setData()
	{
		
		testName="TC3 LOGIN";
		TestDescription="Verify";
		Author="venkatesh";
		category="regression";
	}
}
