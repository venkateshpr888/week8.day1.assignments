package week8.day1.Assignments;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import tc5ForExtentreportSnap.LoginPage5forDelete;






public class Tc5ForExtentreportUsingPOM extends BaseForExtentReports{

	@Test
	public void DeleteLead() throws InterruptedException, IOException {
		new LoginPage5forDelete()
		.typeUserName5("DemoSalesManager")
		.typePassword5("crmsfa")
		.clickLogin5()
		.clickCRMSFA5()
		.clickLeadsTab5()
		.clickFindLead5()
		.clickEmailTab5()
		.typeEmailAddress5("venkatesh@gmail.com")
		.clickFind5()
		.clickFirstName5()
		.ClickDelete5()
		.ClickfindLeadToDelete5()
		.ClickNameTab5()
		.VerifyDeleteLead5();
		
		}
	@BeforeTest
	public void setData()
	{
		
		testName="TC5 CLICK DELETE";
		TestDescription="Verify";
		Author="venkatesh";
		category="regression";
	}
}
