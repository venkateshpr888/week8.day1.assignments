package week8.day1.Assignments;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import testcaseforextentReport.LoginPage1;



public class Tc1ForExtentreportUsingPOM extends BaseForExtentReports {
	@Test
	public void CreateContact() throws IOException {
		new LoginPage1()
		.typeUserName1("DemoCsr2")
		.typePassword1("crmsfa")
		.clickLogin1()
		.clickCRMSFA1()
		.ClickContactsTab1()
		.clickcontact1()
		.typeFirstName1("venkatesh")
		.typeLastName1("Ravi")
		.clickSubmit1()
		.verifyFirstName1();
		
		
		
		
	}
	@BeforeTest
	public void setData()
	{
		
		testName="TC1 USER NAME";
		TestDescription="Verify";
		Author="venkatesh";
		category="regression";
	}

}
