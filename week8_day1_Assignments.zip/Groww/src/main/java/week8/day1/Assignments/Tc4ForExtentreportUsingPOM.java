package week8.day1.Assignments;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import tc4ForExtentreportSnap.LoginPageForDuplicate;




public class Tc4ForExtentreportUsingPOM extends BaseForExtentReports{

	@Test
	public void DuplicateLead() throws InterruptedException, IOException {
		
		new LoginPageForDuplicate()
		.typeUserName4("DemoCsr2")
		.typePassword4("crmsfa")
		.clickLogin4()
		.clickCRMSFA4()
		.clickLeadsTab4()
		.clickFindLead4()
		.clickEmailTab4()
		.typeEmailAddress4("@gmail.com")
		.clickFind4()
		.clickFirstName4()
		.clickDuplicateTab4()
		.clickCreateLead4()
		.verifyLeadforDuplicate4();
		
		
		
		
	}
	@BeforeTest
	public void setData()
	{
		
		testName="TC4 CLICK DUPLICATE";
		TestDescription="Verify";
		Author="venkatesh";
		category="regression";
	}
}
