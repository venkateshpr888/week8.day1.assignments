package tc5ForExtentreportSnap;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class MyHomePage extends BaseForExtentReports{
//	public MyHomePage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public MyLeadsPage clickLeadsTab5() {
		getDriver().findElement(By.xpath("//a[text()='Leads']")).click();
		return new MyLeadsPage();
	}
	
}
