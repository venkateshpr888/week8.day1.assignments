package tc5ForExtentreportSnap;

import org.openqa.selenium.By;

import week8.day1.Assignments.BaseForExtentReports;



public class DeleteLeadPage extends BaseForExtentReports {
	public DeleteLeadPage ClickfindLeadToDelete5() {
		getDriver().findElement(By.xpath("//a[@href='/crmsfa/control/findLeads']")).click();
		return this;
	}
	public ViewLeadsPage1 ClickNameTab5() {
		getDriver().findElement(By.xpath("//input[@name='id']")).sendKeys(text);
		return new ViewLeadsPage1();
	}

}
