package tc5ForExtentreportSnap;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class ViewLeadsPage1 extends BaseForExtentReports {
//	public ViewLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public DeleteLeadPage ClickDelete5() throws InterruptedException, IOException {
		Thread.sleep(2000);
		try {
		getDriver().findElement(By.xpath("(//a[@href='javascript:document.deleteLeadForm.submit()'])")).click();
		reportStep("IN TC5 Clicked Delete Successfully","Pass");
		}catch(Exception e) {
			reportStep("IN TC3 Clicked Delete Not Successfully","Fail");
		}
		return new DeleteLeadPage();
	}
	public ViewLeadsPage1 VerifyDeleteLead5() {
		getDriver().findElement(By.xpath("(//button[text()='Find Leads'])")).click();
		String noRec = getDriver().findElement(By.xpath("//div[text()='No records to display']")).getText();
		String orginal="No records to display";
		System.out.println(noRec);
if (noRec.equals(orginal)) {
	System.out.println("Confirmation - Records Deleted");
} else {
	System.out.println("Confirmation - Records NOT Deleted");
}System.out.println("TC5 Successfull");
return this;
	}
}
