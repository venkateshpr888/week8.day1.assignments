package tc2ForExtentreportSnap;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class ViewLeadsPage extends BaseForExtentReports {
//	public ViewLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public ViewLeadsPage verifyFirstName2() throws InterruptedException {
		Thread.sleep(2000);
		String text = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
	    System.out.println("First name in Create Lead = "+text);
	    System.out.println("TC2 Successfull");
		return this;
	}

}
