package tc2ForExtentreportSnap;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week8.day1.Assignments.BaseForExtentReports;



public class LoginPage2 extends BaseForExtentReports{
//	public LoginPage(ChromeDriver driver) {
//		this.driver=driver;
//		PageFactory.initElements(driver,this);
//	}
	
	/**
	 * Type the user name in the login screen
	 * @param userId -- The different username to login
	 * @return 
	 */
	
	
//	@FindBy(how=How.ID,using= "username")
//	WebElement eleName;
	public LoginPage2 typeUserName2(String userId) {
		getDriver().findElement(By.id("username")).sendKeys(userId);
		return this;
	}
	
	/**
	 * Type the password in the login screen
	 * @param password -- The different password to login
	 * @return 
	 * @throws IOException 
	 */

	public LoginPage2 typePassword2(String password) throws IOException {
		
		try {
		getDriver().findElement(By.id("password")).sendKeys(password);
		reportStep("IN TC2 Entered Password Successfully","Pass");
		}catch(Exception e) {
			reportStep("IN TC2 Entered Password Not Successfully","Fail");
		}
		return this; 
	}
	
	/**
	 * Click the login button
	 * @return 
	 */
	public HomePage clickLogin2() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}

}







