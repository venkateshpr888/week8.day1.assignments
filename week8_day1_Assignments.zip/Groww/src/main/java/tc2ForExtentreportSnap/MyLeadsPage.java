package tc2ForExtentreportSnap;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week8.day1.Assignments.BaseForExtentReports;



public class MyLeadsPage extends BaseForExtentReports{
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public CreateLeadPage clickcreateLead2() {
		getDriver().findElement(By.linkText(prop1.getProperty("linklead"))).click();	
		return new CreateLeadPage();
	}

}
